# Log Directory

```
This directory is used to store log file.
```
